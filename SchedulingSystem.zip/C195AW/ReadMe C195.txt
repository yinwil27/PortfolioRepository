title and purpose of the application
C195 Software 2 , a Scheduler and appointment creator.
�  author, contact information, application version, and date
Ayinde Williams , awi2481@wgu.edu, Application version 0.9 11/25/2020
�  IDE including version number (e.g., IntelliJ Community 2020.01), full JDK of version 11 used (e.g., Java SE 11.0.4), and JavaFX version compatible with JDK 11 (e.g. JavaFX-SDK-11.0.2)
Netbeans IDE 12.0, Java 8, Java FX JavaFX-SDK-11.0.2
�  directions for how to run the program
Download the program.
Open the file inside of a java equipped program
Press "Play" 
�  a description of the additional report of your choice you ran in part A3f
The additional Report I made was a counter for the amount of customers. It is a label inside the reports window.